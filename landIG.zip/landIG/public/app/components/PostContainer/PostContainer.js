import igdata from "../../igdata.js";
import { Attribute } from "../Poust/Post.js";
class MyPostContainer extends HTMLElement {
    constructor() {
        super();
        this.post = [];
        this.attachShadow({ mode: "open" });
        igdata.forEach((p) => {
            const postCard = this.ownerDocument.createElement("my-post");
            postCard.setAttribute(Attribute.profileimg, p.profileimg);
            postCard.setAttribute(Attribute.name, p.name);
            postCard.setAttribute(Attribute.ubication, p.ubication);
            postCard.setAttribute(Attribute.post, p.post);
            postCard.setAttribute(Attribute.views, p.views);
            postCard.setAttribute(Attribute.description, p.description);
            this.post.push(postCard);
        });
    }
    connectedCallback() {
        this.render();
    }
    render() {
        if (this.shadowRoot) {
            this.shadowRoot.innerHTML = "";
            this.post.forEach((post) => {
                var _a;
                (_a = this.shadowRoot) === null || _a === void 0 ? void 0 : _a.appendChild(post);
            });
        }
    }
}
customElements.define("my-postcont", MyPostContainer);
export default MyPostContainer;
