interface DataShape {
    profileimg:string,
    name:string,
    ubication:string,
    post:string,
    views:string,
    description:string
  }
  const postdata: DataShape[] = [
    {
        "profileimg":".././images/perfil.png",
        "name":"Darkseaed1t2",
        "ubication":"Cali",
        "post":".././images/perfil.png",
        "views":"50 views",
        "description":"Darkseaed1t2 cambió su foto de perfil!!"  
    },
    {
        "profileimg":".././images/chad.jpeg",
        "name":"Larry Capija",
        "ubication":"Chupamestepenco",
        "post":".././images/sisoyXD.png",
        "views":"1000 views",
        "description":"No se rían y díganme quién es Rosa Melano"
    },
    {
        "profileimg":".././images/perfil1.jpg",
        "name":"Rosa Melano",
        "ubication":"Kissing-Alemania",
        "post":".././images/jaja.jpg",
        "views":"800 views",
        "description":"Alguien que le diga quién soy a Larry Capija"
    },
    {
        "profileimg":".././images/ahe.jpeg",
        "name":"Alan Brito Delgado",
        "ubication":"Hell-Noruega",
        "post":".././images/postahe.jpeg",
        "views":"678 views",
        "description":"Siempre caliente, nunca incaliente"
    },
    {
        "profileimg":".././images/perfil2.jpg",
        "name":"Elza Potes",
        "ubication":"Australia",
        "post":".././images/tru.jpg",
        "views":"963 views",
        "description":"Yo en el parcial"
    },
    {
        "profileimg":".././images/perfil3.jpg",
        "name":"Susana Oria",
        "ubication":"Iran",
        "post":".././images/ouch.jpeg",
        "views":"5000 views",
        "description":"Con permiso que me voy a zuisidar",
    },
    {
        "profileimg":".././images/perfil5.jpeg",
        "name":"Elba Lazo",
        "ubication":"Turquia",
        "post":".././images/sospechoso.jpg",
        "views":"1200 views",
        "description":"Pasan que cosas",
    },
    {
        "profileimg":".././images/perfil6.jpeg",
        "name":"Mario Neta",
        "ubication":"Conneticut",
        "post":".././images/posi.jpg",
        "views":"50k views",
        "description":"Awebo sisomos",
    },
    {
        "profileimg":".././images/perfil4.jpeg",
        "name":"Armando Bronca Segura",
        "ubication":"Suiza",
        "post":".././images/jsjs.jpg",
        "views":"9871 views",
        "description":"No lo sé, solamente pasa",
    },
    {
        "profileimg":".././images/perfil7.jpg",
        "name":"Armando esteban Quito",
        "ubication":"Rusia",
        "post":".././images/wakuwaku.jpg",
        "views":"100k views",
        "description":"Waku Waku!!!",
    },
];
export default postdata;