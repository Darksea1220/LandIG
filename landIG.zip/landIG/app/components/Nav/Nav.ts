import userdata from "../../userdata.js";
class MySearch extends HTMLElement{
    constructor(){
        super();
        this.attachShadow({mode: "open"});
    }
    connectedCallback(){
        this.render();
    }
    render(){
        if(this.shadowRoot){
            this.shadowRoot.innerHTML = `
            <section>
            <link rel="stylesheet" type="text/css" href="./app/components/Nav/Nav.css">
                <nav class="head">
                <div class="head">
                <img class="log" src="https://github.com/Darksea1220/ComponenteIG/blob/main/Imagesland/log.png?raw=true" class="insta"></img>   
                </div>

                <div class="search">
                <input type="image" class="lupa" src="https://github.com/Darksea1220/ComponenteIG/blob/main/Imagesland/search-regular-24.png?raw=true" class="image_buscar">
                <input type="text" class="busq" placeholder="Buscar"> 
                </div>

                <div class="icons">
                <img class="icon" src="https://github.com/Darksea1220/ComponenteIG/blob/main/Imagesland/home.png?raw=true"></img>
                <img class="icon" src="https://github.com/Darksea1220/ComponenteIG/blob/main/Imagesland/messenger.png?raw=true"></img>
                <img class="icon" src="https://github.com/Darksea1220/ComponenteIG/blob/main/Imagesland/plus.png?raw=true"></img>
                <img class="icon" src="https://github.com/Darksea1220/ComponenteIG/blob/main/Imagesland/compass.png?raw=true"></img>
                <img class="icon" src="https://github.com/Darksea1220/ComponenteIG/blob/main/Imagesland/heart.png?raw=true"></img>
                <my-user clase=user image="${userdata}"></my-user> 
                </div>
                </nav>
            </section>
            `;
        }
    }

}
customElements.define("my-search", MySearch);
export default MySearch;