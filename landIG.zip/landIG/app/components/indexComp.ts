import "./User/User.js";
import "./Nav/Nav.js";
import "./ProfileContainer/ProfileContainer.js";
import "./Profiles/Profiles.js";
import "./Recomendations/Recomendations.js";
import "./SugCont/SugCont.js";